module.exports = {
  version: '0.0.1',
  author: 'whzcorcd'
}