<template>
  <div class="infobar"></div>
</template>

<script>
export default {
  name: 'Infobar'
}
</script>

<style lang="scss" scoped>
.infobar {
  width: 100%;
  height: 340px;
  background: #f7fbfd;
}
</style>